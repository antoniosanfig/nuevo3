﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BitacoraLSC2.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }


        public ActionResult Equipos()
        {
            ViewBag.Message = "Manejo de Equipos";

            return View();
        }
    }
}