﻿namespace BitacoraLSC2.Controllers
{
    public interface IActionResult
    {
    }
}